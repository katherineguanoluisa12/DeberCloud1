/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
  return knex.schema.createTable('customer', table => {
    table.increments('id').primary();
    table.string('name').notNullable();
    table.string('apellido').notNullable();
    table.string('contact_phone');
    table.string('email').notNullable().unique();

    
    table.timestamps(true, true);  // Creación de columnas created_at y updated_at

  });
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
  return knex.schema.dropTable('customer');
};
